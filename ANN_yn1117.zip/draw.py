import numpy as np
import matplotlib.pyplot as plt
import torch

class Draw:
  def __init__(self, x, y, x1_mg, x2_mg, use_torch = False):
    self.use_torch = use_torch
    if self.use_torch:
      x = x.numpy()
      y = y.numpy()

    self.x_pos = x[np.where(y == 1)]
    self.x_neg = x[np.where(y == 0)]
    self.x1_mg = x1_mg
    self.x2_mg = x2_mg

    plt.ion()
    fig, self.ax = plt.subplots(1, 2)

    self.samp_marker = '.'
    self.pos_samp_color = 'crimson'
    self.neg_samp_color = 'indigo'
    self.pos_pred = 'om'
    self.neg_pred = 'oc'

    self.iter = []
    self.loss = []

    self.drawSamples()
    plt.pause(1)
    return
  def drawSamples(self):
    self.ax[0].scatter(self.x_pos[:, 0], self.x_pos[:, 1], color = self.pos_samp_color, marker = self.samp_marker)
    self.ax[0].scatter(self.x_neg[:, 0], self.x_neg[:, 1], color = self.neg_samp_color, marker = self.samp_marker)
    return
  def drawPredict(self, y_):
    if self.use_torch:
      y_ = y_.detach().numpy()
    y_ = np.reshape(y_, self.x1_mg.shape)
    self.ax[0].contourf(self.x1_mg, self.x2_mg, y_, [0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1], cmap = plt.cm.rainbow, zorder = 0)
    plt.pause(0.001)
    # x_pos = x[np.where(y_ <= 0.5)]
    # x_neg = x[np.where(y_ > 0.5)]
    # self.ax[0].plot(x_pos[:, 0], x_pos[:, 1], self.pos_pred)
    # self.ax[0].plot(x_neg[:, 0], x_neg[:, 1], self.neg_pred)
    # self.drawSamples()
    return
  def drawLoss(self, iter, loss):
    self.iter.append(iter)
    self.loss.append(loss)
    self.ax[1].plot(self.iter, self.loss, 'c')
    return
